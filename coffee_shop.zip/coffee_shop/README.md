![](https://github.com/tustoz/coffee_shop_finder/blob/master/coffee-shop-finder.jpg)

# Coffe Shop Finder App

Packages

- [iconsax](https://pub.dev/packages/iconsax)
- [flutter_svg](https://pub.dev/packages/flutter_svg)

Design Credit: [My Self](https://dribbble.com/shots/17145249-Coffee-Shop-Finder-Mobile-App)
